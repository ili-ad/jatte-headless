export const SearchSourceResultsHeader = () => null;
