export const NullComponent = () => null;
