//frontend/src/lib/ChatProvider.tsx
'use client';

import { ReactNode, createContext, useContext, useEffect, useState } from 'react';
import type { Channel as ChannelType, ChatClient } from '@/lib/stream-adapter';
import { Channel as AdapterChannel } from '@/lib/stream-adapter';
import { getStreamClient } from './getStreamClient';
import { getChatCreds } from './getChatCreds';
import { setAuthToken } from '@iliad/stream-chat-shim/api/chatAPI';
import { useSession } from './SessionProvider';

export const chatClient: ChatClient = getStreamClient();

interface ChatContextValue {
  client: ChatClient | null;
  channel: ChannelType | null;
}

const ChatContext = createContext<ChatContextValue>({ client: null, channel: null });

export function useChat() {
  return useContext(ChatContext);
}

export function ChatProvider({ children }: { children: ReactNode }) {
  const { session } = useSession();
  const [client] = useState<ChatClient>(() => chatClient);
  const [channel, setChannel] = useState<ChannelType | null>(null);

  useEffect(() => {
    if (!session) {
      setChannel(null);
      client.disconnectUser();
      setAuthToken(null);
      return;
    }
    let mounted = true;
    (async () => {
      const { userID, userToken } = await getChatCreds();
      setAuthToken(userToken);
      await client.connectUser({ id: String(userID) }, userToken);
      (client as any)['jwt'] = userToken;
      const chan = client.channel('messaging', 'general');
      await chan.watch();
      console.info('[ChatProvider] channel created', {
        isAdapterChannel: chan instanceof AdapterChannel,
        channelClass: chan.constructor?.name,
        clientClass: client.constructor?.name,
      });
      if (!mounted) return;
      setChannel(chan);
    })();
    return () => {
      mounted = false;
      client.disconnectUser();
    };
  }, [client, session]);

  useEffect(() => {
    if (!channel) return;
    const handleNew = () => channel.markRead();
    channel.on('message.new', handleNew);
    return () => {
      channel.off('message.new', handleNew);
    };
  }, [channel]);

  return (
    <ChatContext.Provider value={{ client, channel }}>
      {children}
    </ChatContext.Provider>
  );
}
