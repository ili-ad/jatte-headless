"""Smalltalk-related agent skills."""
