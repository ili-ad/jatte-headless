"""Utility agent skills."""
